# Design System Document

## 1. Overview & Creative North Star: The Midnight Garden
This design system is anchored by the creative north star of **"The Midnight Garden."** It is a digital sanctuary that avoids the sterile, flat aesthetic of standard utilities. Instead, it prioritizes a sense of organic calm and premium editorial depth. By leveraging deep forest greens (`#041710`) and high-contrast mint accents (`#74C69D`), the system creates a high-end atmosphere that feels both authoritative and restorative.

The interface moves away from "boxed" layouts toward **intentional asymmetry** and **atmospheric layering**. We break the grid by using generous, varied spacing and overlapping typography to guide the eye, ensuring that every screen feels like a curated experience rather than a template.

---

## 2. Colors
Our palette mimics the transition of light in a dense forest at night. High contrast is mandatory for readability, ensuring that the soft greens pop against the deep, obsidian backgrounds.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders for sectioning or containers. Structural boundaries must be defined solely through background color shifts. For instance, a section using `surface_container_low` should sit directly on a `surface` background. The change in tonal depth is the divider.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked, physical layers.
- **Base Layer:** `surface` (#041710).
- **Secondary Depth:** `surface_container` (#10231c).
- **Prominent Nesting:** `surface_container_high` (#1a2e26).
- **Call-to-Action Layer:** `primary_container` (#1B4332).

### The "Glass & Gradient" Rule
To elevate the experience, use **Glassmorphism** for floating elements (like Navigation Bars or Modals). Use semi-transparent versions of `surface_variant` with a 20px-40px `backdrop-blur`. 

### Signature Textures
Apply subtle linear gradients to primary buttons and hero sections. Transition from `primary` (#a5d0b9) to `primary_container` (#1B4332) at a 135-degree angle to provide a "silk-like" finish that flat hex codes cannot replicate.

---

## 3. Typography
The system uses a bilingual typographic pairing designed for editorial clarity and cultural resonance.

*   **Latin:** *Be Vietnam Pro* — A clean, geometric sans-serif that provides a modern, breathable feel.
*   **Arabic:** *Tajawal* — Chosen for its low-contrast, fluid strokes that mirror the organic nature of the brand.

### Typographic Identity
- **Display Scale:** Use `display-lg` (3.5rem) with tighter letter-spacing (-0.02em) to create a bold, "magazine-style" header.
- **Bilingual Balance:** When pairing *Tajawal* and *Be Vietnam Pro*, ensure the Arabic weight is one step lower (e.g., Arabic Regular with Latin Medium) to achieve perceived visual weight parity.
- **The Sukun Detail:** The logo 'أُنْس' must always feature the Sukun on the Noon as a central brand mark, symbolizing the "quiet" or "pause" the sanctuary provides.

---

## 4. Elevation & Depth
We eschew traditional drop shadows in favor of **Tonal Layering**.

- **The Layering Principle:** Softness is achieved by stacking. Place a `surface_container_lowest` card on a `surface_container_low` section. This creates a natural, "etched" look.
- **Ambient Shadows:** If a floating effect is required (e.g., for a FAB), use a shadow color derived from `on_surface` at 6% opacity with a Blur radius of 32px and a Y-offset of 16px. This mimics a soft, moonlit glow.
- **The "Ghost Border" Fallback:** If a container requires a border for accessibility, use `outline_variant` at **15% opacity**. Never use a 100% opaque border.
- **Tactile Softness:** Every container follows the **Round Eight** rule. All corners must use the `DEFAULT` (0.5rem) or `lg` (1rem) tokens to maintain the "Midnight Garden" organic feel.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (Primary to Primary Container). Roundedness: `full`. No border.
- **Secondary:** Surface-tinted background (`surface_container_highest`) with `on_primary_container` text. 
- **Tertiary:** No background. Text uses `primary` (#a5d0b9).

### Inputs & Fields
- **Text Inputs:** Use `surface_container_lowest` for the field fill. 
- **States:** On focus, transition the background to `surface_container_highest` and provide a "Ghost Border" using `primary` at 20% opacity.
- **Error:** Use `error` (#ffb4ab) only for text; do not outline the entire box in red unless the error is critical.

### Cards & Lists
- **The Divider Ban:** Strictly forbid 1px horizontal lines. Use the **Spacing Scale** (token `6` or `8`) to create "Active Negative Space."
- **Nesting:** Place content inside `surface_container` modules to separate it from the global background.

### Signature Component: The "Zen Pulse"
A custom selection chip used for status. It features a soft, breathing animation (opacity 40% to 100%) using the `secondary` (#85d7ad) color, signaling an active, calm state.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical margins (e.g., `spacing.12` on the left and `spacing.6` on the right) for editorial layouts.
*   **Do** prioritize `primary` (#a5d0b9) for icons to ensure they pass high-contrast accessibility tests against the dark green background.
*   **Do** use `backdrop-blur` on all overlays to maintain the "Midnight Garden" depth.

### Don't
*   **Don't** use gold or yellow. All legacy accents must be replaced with the Mint/Soft Green palette (`#74C69D`).
*   **Don't** use pure black (#000000). Always use the `surface` (#041710) token to keep the "Forest" tonality.
*   **Don't** crowd elements. If in doubt, increase the spacing by one token on the scale.
*   **Don't** use hard-edged rectangles. Every element must adhere to the **Round Eight** (0.5rem) minimum.